package com.example.elasticsearch.demos.web.controller.base;

import com.example.elasticsearch.demos.web.model.dto.DocDto;
import com.example.elasticsearch.demos.web.service.base.IndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 基础操作-索引操作
 */
@RestController
@RequestMapping("/index")
public class IndexController {

    @Autowired
    private IndexService indexService;

    /**
     * 验证索引是否存在
     * indexName = "mydlq-user"
     * @return
     */
    @PostMapping("/exist")
    public Object existIndex(@RequestBody DocDto docDto) {
        return indexService.existsIndex(docDto.getIndexName());
    }

    /**
     * 新增加索引
     * @return
     */
    @PostMapping("/create")
    public Object createIndex(@RequestBody DocDto docDto) {
        return indexService.createIndex(docDto.getIndexName());
    }

    /**
     * 删除索引
     * @return
     */
    @PostMapping("/delete")
    public Object deleteIndex(@RequestBody DocDto docDto) {
        return indexService.deleteIndex(docDto.getIndexName());
    }

}
