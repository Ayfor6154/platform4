package com.example.elasticsearch.demos.web.model.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TermsQueryDto {

    /**
     * 索引名称
     */
    private String indexName;
    private String key;
    private String value;
    private String[] values;
}
