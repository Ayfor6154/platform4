package com.example.elasticsearch.demos.web.controller.aggregation;

import com.example.elasticsearch.demos.web.service.aggregation.AggrBucketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 聚合—分桶聚合查询
 */
@RestController
@RequestMapping("/bucket")
public class AggrBucketController {

    @Autowired
    private AggrBucketService aggrBucketService;

    /**
     * 按词分桶, 根据拆分的词不同，将对于的词分到不同的桶中
     *
     * @return
     */
    @PostMapping("/terms")
    public Object bucketTerms() {
        return aggrBucketService.aggrBucketTerms();
    }

    /**
     * 指定数值范围分桶, 指定一个数值范围，然后按这个数值范围为进行分桶
     */

    @PostMapping("/range")
    public Object bucketRange() {
        return aggrBucketService.aggrBucketRange();
    }

    /**
     * 根据日期范围分桶, 指定一个日期范围，然后按这个日期范围进行分桶
     *
     * @return
     */
    @PostMapping("/dateRange")
    public Object bucketDateRange() {
        return aggrBucketService.aggrBucketDateRange();
    }

    /**
     * 数值直方图, 根据数值范围输出直方图数据
     *
     * @return
     */
    @PostMapping("/histogram")
    public Object bucketHistogram() {
        return aggrBucketService.aggrBucketHistogram();
    }

    /**
     * 日期直方图, 根据日期范围输出直方图数据
     *
     * @return
     */
    @PostMapping("/dateHistogram")
    public Object bucketDateHistogram() {
        return aggrBucketService.aggrBucketDateHistogram();
    }

}
