package com.example.elasticsearch.demos.web.controller.query;

import com.example.elasticsearch.demos.web.model.dto.MatchQueryDto;
import com.example.elasticsearch.demos.web.service.query.BoolQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 查询-布尔查询
 */
@RestController
@RequestMapping("/query")
public class BoolQueryController {

    @Autowired
    private BoolQueryService boolQueryService;

    /**
     * 布尔(AND、OR、NOT)查询, 多个条件组合查询
     *
     * @return
     */
    @PostMapping("/bool")
    public Object boolQuery(@RequestBody MatchQueryDto queryDto) {
        return boolQueryService.boolQuery(queryDto);
    }

}
