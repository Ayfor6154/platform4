package com.example.elasticsearch.demos.web.model.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * DocDto
 *
 * @author venlenter
 * @Description: TODO
 * @since unknown, 2023-10-04
 */
public class DocDto implements Serializable {

    private static final long serialVersionUID = -7579556700841300697L;

    /**
     * 索引名称
     */
    private String indexName;

    /**
     * docId
     */
    private String docId;

    /** 姓名 */
    private String name;
    /** 地址 */
    private String address;
    /** 岁数 */
    private Integer age;
    /** 工资 */
    private Float salary;
    /** 出生日期 */
    private String birthDate;
    /** 备注信息 */
    private String remark;

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Float getSalary() {
        return salary;
    }

    public void setSalary(Float salary) {
        this.salary = salary;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
