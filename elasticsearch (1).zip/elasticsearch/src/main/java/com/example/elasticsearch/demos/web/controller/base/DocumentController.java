package com.example.elasticsearch.demos.web.controller.base;

import com.example.elasticsearch.demos.web.model.dto.DocDto;
import com.example.elasticsearch.demos.web.service.base.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 基础操作-文档操作
 */
@RestController
@RequestMapping("/document")
public class DocumentController {

    @Autowired
    DocumentService documentService;

    /**
     * 获取文档
     *
     * @return
     */
    @PostMapping("/get")
    public Object getDocument(@RequestBody DocDto docDto) {
        return documentService.getDocument(docDto);
    }

    /**
     * 验证文档是否存在
     *
     * @return
     */
    @PostMapping("/exist")
    public Object existDocument(@RequestBody DocDto docDto) {
        return documentService.existsDocument(docDto);
    }

    /**
     * 新增文档
     *
     * @return
     */
    @PostMapping("/add")
    public Object addDocument(@RequestBody DocDto docDto) {
        return documentService.addDocument(docDto);
    }

    /**
     * 更新文档
     *
     * @return
     */
    @PostMapping("/update")
    public Object updateDocument(@RequestBody DocDto docDto) {
        return documentService.updateDocument(docDto);
    }

    /**
     * 删除文档
     *
     * @return
     */
    @PostMapping("/delete")
    public Object deleteDocument(@RequestBody DocDto docDto) {
        return documentService.deleteDocument(docDto);
    }

}
