package com.example.elasticsearch.demos.web.controller.query;

import com.example.elasticsearch.demos.web.model.dto.MatchQueryDto;
import com.example.elasticsearch.demos.web.service.query.WildcardQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 查询-通配符查询
 */
@RestController
@RequestMapping("/query")
public class WildcardQueryController {

    @Autowired
    private WildcardQueryService wildcardQueryService;

    /**
     * 通配符查询
     *
     * @return
     */
    @PostMapping("/wildcard")
    public Object wildcardQuery(@RequestBody MatchQueryDto queryDto) {
        return wildcardQueryService.wildcardQuery(queryDto);
    }

}
