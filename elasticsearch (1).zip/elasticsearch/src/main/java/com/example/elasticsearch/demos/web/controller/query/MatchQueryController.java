package com.example.elasticsearch.demos.web.controller.query;

import com.example.elasticsearch.demos.web.model.dto.MatchQueryDto;
import com.example.elasticsearch.demos.web.service.query.MatchQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 查询-匹配查询
 */
@RestController
@RequestMapping("/query")
public class MatchQueryController {

    @Autowired
    private MatchQueryService matchQueryService;

    /**
     * 匹配查询-全部数据
     *
     * @return
     */
    @PostMapping("/matchAll")
    public Object matchQueryAll(@RequestBody MatchQueryDto queryDto) {
        return matchQueryService.matchAllQuery(queryDto);
    }

    /**
     * 匹配查询数据-or的方式
     *
     * @return
     */
    @PostMapping("/match")
    public Object matchQuery(@RequestBody MatchQueryDto queryDto) {
        return matchQueryService.matchQuery(queryDto);
    }

    /**
     * 词语匹配查询
     *
     * @return
     */
    @PostMapping("/matchPhrase")
    public Object matchPhraseQuery(@RequestBody MatchQueryDto queryDto) {
        return matchQueryService.matchPhraseQuery(queryDto);
    }

    /**
     * 多字段匹配查询
     *
     * @return
     */
    @PostMapping("/matchMulti")
    public Object matchMultiQuery(@RequestBody MatchQueryDto queryDto) {
        return matchQueryService.matchMultiQuery(queryDto);
    }

}
