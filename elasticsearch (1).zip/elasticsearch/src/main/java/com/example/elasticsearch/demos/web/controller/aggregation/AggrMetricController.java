package com.example.elasticsearch.demos.web.controller.aggregation;

import com.example.elasticsearch.demos.web.model.dto.MatchQueryDto;
import com.example.elasticsearch.demos.web.service.aggregation.AggrMetricService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 聚合—聚合分析
 */
@RestController
@RequestMapping("/aggr")
public class AggrMetricController {

    @Autowired
    private AggrMetricService aggrMetricService;

    /**
     * 聚合后求各个数据值的平均值
     *
     * @return
     */
    @PostMapping("/avg")
    public Object avgAggrMetric() {
        return aggrMetricService.aggregationAvg();
    }

    /**
     * 聚合后求各个数据值的总数
     *
     * @return
     */
    @PostMapping("/count")
    public Object countAggrMetric() {
        return aggrMetricService.aggregationCount();
    }

    /**
     * 聚合后求各个数据值的最大值
     *
     * @return
     */
    @PostMapping("/max")
    public Object maxAggrMetric() {
        return aggrMetricService.aggregationMax();
    }

    /**
     * 聚合后求各个数据值的最小值
     *
     * @return
     */
    @PostMapping("/min")
    public Object minAggrMetric() {
        return aggrMetricService.aggregationMin();
    }

    /**
     * 聚合后求各个数据值的百分位
     *
     * @return
     */
    @PostMapping("/percentiles")
    public Object percentilesAggrMetricr() {
        return aggrMetricService.aggregationPercentiles();
    }

    /**
     * 聚合后求各个数据值的和
     *
     * @return
     */
    @PostMapping("/sum")
    public Object sumAggrMetric() {
        return aggrMetricService.aggregationSum();
    }

    /**
     * 聚合后求各个数据值的统计(count)、平均(avg)、最大(max)、最小(min)、求和值(sum)的值
     *
     * @return
     */
    @PostMapping("/stats")
    public Object statsAggrMetric(@RequestBody MatchQueryDto queryDto) {
        return aggrMetricService.aggregationStats(queryDto);
    }

}
