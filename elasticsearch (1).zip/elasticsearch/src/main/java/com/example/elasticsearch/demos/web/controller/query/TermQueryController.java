package com.example.elasticsearch.demos.web.controller.query;

import com.example.elasticsearch.demos.web.model.dto.TermsQueryDto;
import com.example.elasticsearch.demos.web.service.query.TermQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 查询-精确查询
 */
@RestController
@RequestMapping("/query")
public class TermQueryController {

    @Autowired
    private TermQueryService termQueryService;

    /**
     * 精确查询
     * @return
     */
    @PostMapping("/term")
    public Object termQuery(@RequestBody TermsQueryDto queryDto) {
        return termQueryService.termQuery(queryDto);
    }

    /**
     * 精确查询一个字段多个值
     * @return
     */
    @PostMapping("/terms")
    public Object termsQuery(@RequestBody TermsQueryDto queryDto) {
        return termQueryService.termsQuery(queryDto);
    }

}
