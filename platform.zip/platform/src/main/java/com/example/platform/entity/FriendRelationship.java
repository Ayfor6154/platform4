package com.example.platform.entity;


import java.util.Date;

/**
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:44:44
 */
public class FriendRelationship {

	private int ID;
	private int Player1ID;
	private int Player2ID;
	private Date DateTime;
	public Player m_Player;

	public FriendRelationship(){

	}

	public void finalize() throws Throwable {

	}

}