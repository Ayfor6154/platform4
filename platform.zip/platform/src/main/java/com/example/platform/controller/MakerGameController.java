package com.example.platform.controller;

public class MakerGameController {
}
