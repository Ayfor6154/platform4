package com.example.platform.entity;


/**
 * 这个需要description吗
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:39:04
 */
public class OrderStatus {

	private int ID;
	private char Name;
	private char Description;

	public OrderStatus(){

	}

	public void finalize() throws Throwable {

	}

}