package com.example.platform.entity;


/**
 * 他继承了Rating类
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:43:58
 */
public class RatingofResponse extends Rating {

	private int RatingID;

	public RatingofResponse(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}