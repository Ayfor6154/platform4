package com.example.platform.entity;


/**
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:39:37
 */
public class GameState {

	private int ID;
	private char Name;

	public GameState(){

	}

	public void finalize() throws Throwable {

	}

}