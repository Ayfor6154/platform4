package com.example.platform.test;

import com.example.platform.config.CurrentUser;
import org.springframework.web.bind.annotation.GetMapping;
/*
@GetMapping("/test")
//@LoginRequired
public Object testCurrentUser(@CurrentUser User user) {
    return user;
}
*/