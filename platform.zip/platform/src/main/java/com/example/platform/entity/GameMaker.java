package com.example.platform.entity;


/**
 * 游戏厂商
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:40:39
 */
public class GameMaker extends User {

	public GameMaker(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}