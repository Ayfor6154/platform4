package com.example.platform.entity;


/**
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:27:40
 */
public class Stuff extends User {

	public Stuff(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}