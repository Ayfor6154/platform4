package com.example.platform.entity;


/**
 * 游戏类型
 * @author Lenovo
 * @version 1.0
 * @created 25-4月-2023 16:40:04
 */
public class Type {

	private int ID;
	private char Name;
	private char Description;

	public Type(){

	}

	public void finalize() throws Throwable {

	}

}